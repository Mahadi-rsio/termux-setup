-- get NVChad LSP defaults (no .defaults() call)
local nvlsp = require("nvchad.configs.lspconfig")

-- list of LSP servers
local servers = {
  "html",
  "cssls",
  "tailwindcss",
  "ts_ls",  -- correct TS server name
}

for _, lsp in ipairs(servers) do
  require("lspconfig")[lsp].setup({
    on_attach = nvlsp.on_attach,
    on_init = nvlsp.on_init,
    capabilities = nvlsp.capabilities,
  })
end
